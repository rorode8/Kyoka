package Kyoka.commands.command;

import java.util.Hashtable;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import com.jagrosh.jdautilities.commons.waiter.EventWaiter;

import Kyoka.commands.CommandContext;
import Kyoka.commands.ICommand;
import Kyoka.utils.MongoDB;

public class FishCommand implements ICommand {
	private final EventWaiter waiter = new EventWaiter();
	private static Hashtable<Long,Long> timeout = new Hashtable<Long,Long>();
	private static Timer timer = new Timer();


	@Override
	public void handle(CommandContext ctx) {
		
		
		// TODO Auto-generated method stub
		if(MongoDB.userExists(ctx.getAuthor().getIdLong())) {
			if(timeout.containsKey(ctx.getAuthor().getIdLong())) {
				//wait message
				ctx.getChannel().sendMessage("you may fish once every 60 seconds").queue();
			}else {
				timeout.put(ctx.getAuthor().getIdLong(), ctx.getAuthor().getIdLong());
				ctx.getChannel().sendMessage("fishing...").queue((message)->{
					
					message.editMessage("fish!").queueAfter(2, TimeUnit.SECONDS);
					
				});
				untime(ctx.getAuthor().getIdLong());
			}
			
		}else {
			ctx.getChannel().sendMessage("you must user the register command first").queue();
		}
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "fish";
	}

	@Override
	public String getHelp() {
		// TODO Auto-generated method stub
		return "go fishing!! to use this command register first";
	}
	
	private void untime(long id) {
		TimerTask task = new TimerTask() {
			@Override
			public void run() {
				timeout.remove(id, id);
			}
		};
		timer.schedule(task, 60000l);
		
		
	}

}
