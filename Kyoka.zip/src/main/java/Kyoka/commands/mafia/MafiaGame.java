package Kyoka.commands.mafia;

import java.util.List;

public class MafiaGame {
	
	private List<MafiaPlayer> players;

}
