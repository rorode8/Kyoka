package Kyoka.commands.mafia;

import net.dv8tion.jda.api.entities.Member;

public class MafiaPlayer {
	
	private Member member;
	private String role;

}
