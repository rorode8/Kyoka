package Kyoka.items;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.bson.Document;

public class FishCommand implements dropItem {
	
	private int luckWeight;
	private int weight;
	private String name;
	private int id;
	private int kgprice;
	private Random r = new Random();
	

	public FishCommand(String line) {
		super();
		List<String> items = new ArrayList<String>(Arrays.asList(line.split(" ,")));
		
		this.luckWeight = Integer.parseInt(items.get(5));
		this.weight = r.nextInt(Integer.parseInt(items.get(4))-Integer.parseInt(items.get(3))+1)+Integer.parseInt(items.get(4));	//ugly
		this.kgprice = Integer.parseInt(items.get(2));
		this.name = items.get(1);
		this.id = Integer.parseInt(items.get(0));
		
		
	}

	@Override
	public int getWeight() {
		return luckWeight;
				
	}

	@Override
	public Document getDoc() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getId() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double sellValue() {
		// TODO Auto-generated method stub
		return 0;
	}

}
