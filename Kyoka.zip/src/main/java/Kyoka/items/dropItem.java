package Kyoka.items;

import org.bson.Document;

public interface dropItem {
	
	public int getWeight();
	
	public Document getDoc();
	
	public int getId();
	
	public double sellValue();

}
