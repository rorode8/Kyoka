package Kyoka.items;

import java.util.List;

public class ItemPuller {
	
	private List<dropItem> items;
	private int totalWeight;
	

}
