package Kyoka;

import me.duncte123.botcommons.messaging.EmbedUtils;
import me.duncte123.botcommons.web.WebUtils;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.entities.Activity;

import javax.security.auth.login.LoginException;

import Kyoka.utils.MongoDB;

public class Bot {
	
	private Bot() {
		//prep
		WebUtils.setUserAgent("");
		MongoDB.connect();
		Kyoka.utils.DataLoader.Start("settings.JSON");
		EmbedUtils.setEmbedBuilder(
				() -> new EmbedBuilder()
				.setColor(0xe0102c)
				.setFooter("Kyoka")
				
				);
		
		try {
		JDA jda  = JDABuilder.createDefault(Kyoka.utils.DataLoader.getString("token"))
				.addEventListeners(new Listener())
				.setActivity(Activity.listening("x"))
				.build();
		
		
		}catch(Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		new Bot();
	}

}
