package Kyoka.utils;

import java.util.ArrayList;
import java.util.List;

import org.bson.BsonDocument;
import org.bson.Document;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;


public class MongoDB {
	
	private static MongoClient mongoClient;
	private static MongoDatabase  database;
	private static MongoCollection<Document> users;
	
	
	
	public static void connect() {
		
		String ur = "mongodb+srv://user1:analytics-password@isabelle.jawe2.mongodb.net/discord?retryWrites=true&w=majority";
		mongoClient = MongoClients.create(ur);
		
		database = mongoClient.getDatabase("discord");
		users = database.getCollection("users");
		
		System.out.println(database.getName());
		System.out.println(users.countDocuments());
		//System.out.println(database.toString());
		
		/*
		 * 
		
		MongoDatabase mongoDatabase = mongoClient.getDatabase("KyokaBot");
		MongoCollection collection = mongoDatabase.getCollection("Collection");
		
		Document doc = new Document("id", "3333131");
		
		doc.append("Sex", "male");
		doc.append("Age", "21");
		doc.append("Race", "Hispanic");
		
		collection.insertOne(doc);
		 */
		
		
		
		
		
	}
	
	public static boolean userExists(long id) {
		BsonDocument b;
		//col.find(eq("_id",id));
		return users.find(new Document("_id",id)).cursor().hasNext();
		
		
	}
	
	public static void createDocument(long id) {
		List<Document> docs = new ArrayList<Document>();
		users.insertOne(new Document("_id",id).append("money", 0D).append("Objects", docs));
		
	}
	
	public static void pushIntoObjects(long id) {
		Document chill = new Document("itemId",0).append("type", "sword");
		users.updateOne(Filters.eq("_id",id), Updates.addToSet("Objects", chill));
	}

}
