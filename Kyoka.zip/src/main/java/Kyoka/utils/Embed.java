package Kyoka.utils;

public class Embed {
	
	

}
